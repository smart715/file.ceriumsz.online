<?php

namespace App\Http\Controllers;

use App\Models\AccountHistor;
use Illuminate\Http\Request;

class AccountHistorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\AccountHistor  $accountHistor
     * @return \Illuminate\Http\Response
     */
    public function show(AccountHistor $accountHistor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\AccountHistor  $accountHistor
     * @return \Illuminate\Http\Response
     */
    public function edit(AccountHistor $accountHistor)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\AccountHistor  $accountHistor
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, AccountHistor $accountHistor)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\AccountHistor  $accountHistor
     * @return \Illuminate\Http\Response
     */
    public function destroy(AccountHistor $accountHistor)
    {
        //
    }
}
