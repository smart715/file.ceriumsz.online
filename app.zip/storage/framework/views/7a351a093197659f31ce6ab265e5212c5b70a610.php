
<?php $__env->startSection('title', 'home'); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('link'); ?>

<style>
        .icon-size-css {
            font-size: 35px;
            padding: 50px;

        }
    </style>

    <style>
        h4.card-title {
            font-weight: 700;
            font-size: 18px !important;
        }

        .card-header table tr td {
            vertical-align: middle;
            font-size: 14px;
            color: #515151;
            padding: 0 0 150px 150px !important;
        }

        .card-header table tr td[scope="row"] {
            font-weight: 500 !important;
        }
    </style>
    <?php $__env->stopSection(); ?>
    <div class="container">
    
    <div class="main-panel">

<div class="content-wrapper">
 
        <div class="row">
            <div class="col-12 ">
                <div class="card">
                    <div class="card-header" >debtors</div>
                    <div class="card-body">
                        <a href="<?php echo e(url('/debtors/create')); ?>" class="btn btn-success btn-sm" title="Add New Contact">
                            <i class="fa fa-plus" aria-hidden="true"></i> Add New
                        </a>
                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Account#</th>
                                        <th>ClientName</th>
                                        <th>DebtorName</th>
                                        <th>Contacts</th>
                                        <th>Amount</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $debtors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($item->accountno); ?></td>
                                        <td><?php echo e($item->client_name); ?></td>
                                        <td><?php echo e($item->debtor_first_name); ?></td>
                                        <td><?php echo e($item->cell); ?></td>
                                        <td><?php echo e($item->totalbalance); ?></td>
 
                                        <td>
                                            <a href="<?php echo e(url('debtor/detail',$item->id)); ?>" title="View Student"><button class="btn btn-info btn-sm"><i class="fa fa-eye" aria-hidden="true"></i> View</button></a>
                                            <a href="<?php echo e(url('/debtors/' . $item->id . '/edit')); ?>" title="Edit Student"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>
 
                                            <form method="POST" action="<?php echo e(url('/debtors' . '/' . $item->id)); ?>" accept-charset="UTF-8" style="display:inline">
                                                <?php echo e(method_field('DELETE')); ?>

                                                <?php echo e(csrf_field()); ?>

                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete debtors" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
 
                    </div>
                </div>
                </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('componant.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/celothus/file.ceriumsz.online/resources/views/debtors/index.blade.php ENDPATH**/ ?>