<?php $__env->startSection('title', 'home'); ?>
<?php $__env->startSection('link'); ?>
<style>
    .icon-size-css{
        font-size:35px;
        padding: 10px;
        padding-left: 90px;
    }

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="row">
                    <div class="col-1"><i class="icon-size-css icon-envelope"></i></div>
                    <div class="col-1"><i class="icon-size-css icon-phone"></i></div>
                    <div class="col-1"><i class="icon-size-css icon-direction"></i></div>
                    <div class="col-1"><i class="icon-size-css icon-screen-smartphone"></i></div>
                    <div class="col-1"><i class="icon-size-css icon-user"></i></div>
                    <div class="col-1"><i class="icon-size-css icon-dislike"></i></div>
                    <div class="col-1"><i class="icon-size-css icon-like"></i></div>
                    <div class="col-1"><i class="icon-size-css icon-speech"></i></div>
                    <div class="col-1"><i class="icon-size-css icon-clock"></i></div>
                    <div class="col-1"><i class="icon-size-css icon-note"></i></div>
                    

                </div>




                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Debtor</h4>
                        <div class="row">
                            <div class="col-12 table-responsive">
                                <?php echo e(var_dump($debtors)); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         <?php echo $__env->make('componant.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('componant.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbookpro/Desktop/debtor/resources/views/user/debtor/index.blade.php ENDPATH**/ ?>