
<?php $__env->startSection('title', 'home'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">   
<div class="main-panel">
<div class="content-wrapper">
<div class="card">
  <div class="card-header">Clients Page</div>
  <div class="card-body">
  
        <div class="card-body">
        <h5 class="card-title">Name : <?php echo e($clients->name); ?></h5>
        <h5 class="card-title">Name : <?php echo e($clients->group); ?></h5>
        <p class="card-text">Address : <?php echo e($clients->location); ?></p>
        <p class="card-text">Phone : <?php echo e($clients->contacts); ?></p>
  </div>
      
    </hr>
  
  </div>
</div>
</div>
</div>
</div>


<?php echo $__env->make('componant.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/celothus/file.ceriumsz.online/resources/views/clients/show.blade.php ENDPATH**/ ?>