<!DOCTYPE html>
<html lang="en">


 <head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Flare Premium Bootstrap Admin Dashboard Template</title>

  <link rel="stylesheet" href="<?php echo e(url('vendors/iconfonts/simple-line-icon/css/simple-line-icons.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('vendors/css/vendor.bundle.base.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(url('vendors/css/vendor.bundle.addons.css')); ?>">

  <link rel="stylesheet" href="<?php echo e(url('css/style.css')); ?>">

  <link rel="shortcut icon" href="images/favicon.png" />
</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>

  <script src="<?php echo e(url('vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(url('vendors/js/vendor.bundle.addons.js')); ?>"></script>

  <script src="<?php echo e(url('js/template.js')); ?>"></script>

</body>
</html>

<?php /**PATH C:\Users\h\appppp\resources\views/layouts/app.blade.php ENDPATH**/ ?>