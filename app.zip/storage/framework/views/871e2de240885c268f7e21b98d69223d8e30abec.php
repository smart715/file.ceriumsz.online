<?php $__env->startSection('title', 'home'); ?>

<?php $__env->startSection('content'); ?>

    <div class="">
        <div class="">
            <div class="content-wrapper">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Debtor</h4>
                        <div class="row">
                            <div class="col-12 table-responsive">
                                <table id="order-listing" class="table">
                                    <thead>
                                        <tr>
                                            <th>ID #</th>
                                            <th>Id Number</th>
                                            <th>Client Name</th>
                                            <th>Debtor Name</th>
                                            <th>Email</th>
                                            <th>Contact No</th>
                                            <th>Amount</th>
                                            <th>Interest Rate</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $debtors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$debtor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($debtor->id_number); ?></td>
                                            <td><?php echo e($debtor->debtor_first_name); ?></td>
                                            <td><?php echo e($debtor->first_name); ?></td>
                                            <td><?php echo e($debtor->email); ?></td>
                                            <td><?php echo e($debtor->contact_no); ?></td>
                                            <td><?php echo e($debtor->amount); ?></td>

                                                <td><?php echo e($debtor->interest_rate); ?></td>



                                                <td>
                                                     <i class="icon-credit-card" style="font-size: 20px;margin-right: 12px;"></i>
                                                  <a href="<?php echo e(url('debtor',$debtor->id)); ?>">  <i class="icon-eye" style="font-size: 20px;margin-right: 12px;"></i></a>
                                                    <i class="icon-pencil" style="font-size: 20px;margin-right: 12px;"></i>
                                                    <i class="icon-trash" style="font-size: 20px;margin-right: 12px;"></i>
                                                </td>

                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           <?php echo $__env->make('componant.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('componant.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\h\appppp\resources\views/debtor/index.blade.php ENDPATH**/ ?>