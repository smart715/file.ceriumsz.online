<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2022 <a
                href="http://www.mibureau.co.za/" target="_blank">Smart Debt Collect</a>. All rights
            reserved.</span>
        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">a Product of Mi Bureau & made with <i
                class="icon-heart text-danger"></i></span>
    </div>
</footer>
<?php /**PATH /home/celothus/debt.celothusi.xyz/resources/views/componant/footer.blade.php ENDPATH**/ ?>