<?php $__env->startSection('title', 'home'); ?>

<?php $__env->startSection('content'); ?>

    <div class="container-fluid page-body-wrapper">
        <div class="main-panel">
            <div class="content-wrapper">
                <div class="row">
                    <div class="col-md-6 col-lg-3 grid-margin stretch-card">
                        <div class="card bg-dark text-white border-0">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <p style="border-bottom: 1px solid;"> User detail</p>
                                </div>
                                <table class="  table-borderless">
                                    <thead>

                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>name:</td>
                                            <td><?php echo e(Auth::user()->name); ?></td>

                                        </tr>
                                        <tr>
                                            <td>Contact:</td>
                                            <td>3298932889</td>

                                        </tr>
                                        <tr>
                                            <td>email:</td>
                                            <td><?php echo e(Auth::user()->email); ?></td>

                                        </tr>

                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-6 grid-margin stretch-card">
                        <div class="card bg-primary text-white border-0">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <p style="border-bottom: 1px solid;"> Daily Status</p>
                                </div>


                                <div class="row">
                                    <div class="col-md-6">
                                        <table class="table-borderless">

                                            <tbody>
                                                <tr>
                                                    <td>#Of Calls:</td>
                                                    <td>0</td>

                                                </tr>
                                                <tr>
                                                    <td>#Of SMS:</td>
                                                    <td>0</td>

                                                </tr>
                                                <tr>
                                                    <td>#Of Email:</td>
                                                    <td>0</td>

                                                </tr>
                                                <tr>
                                                    <td>#Of Accounts:</td>
                                                    <td>0</td>

                                                </tr>


                                            </tbody>
                                        </table>
                                    </div>
                                    <div class="col-md-6">
                                        <table class="table-borderless">

                                            <tbody>
                                                <tr>
                                                    <td>#Of RTP:</td>
                                                    <td>0</td>

                                                </tr>
                                                <tr>
                                                    <td>#Of AOD:</td>
                                                    <td>0</td>

                                                </tr>
                                                <tr>
                                                    <td>#Of PTPs:</td>
                                                    <td><?php echo e($ptpcount); ?></td>

                                                </tr>
                                                <tr>
                                                    <td>#Of RCP:</td>
                                                    <td>0</td>

                                                </tr>


                                            </tbody>
                                        </table>
                                    </div>
                                </div>



                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3 grid-margin stretch-card">
                        <div class="card bg-success text-white border-0">
                            <div class="card-body">
                                <div class="d-flex align-items-center">
                                    <p style="border-bottom: 1px solid;"> Reminders</p>

                                </div>
                                <table class="table-borderless">

                                    <tbody>
                                        <tr>
                                            <td>#Of Failed PTP's:</td>
                                            <td>0</td>

                                        </tr>
                                        <tr>
                                            <td>#Of Pre Term:</td>
                                            <td>0</td>

                                        </tr>
                                        <tr>
                                            <td># AOD:</td>
                                            <td>0</td>

                                        </tr>



                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>




                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Debtor</h4>
                        <div class="row">
                            <div class="col-12 table-responsive">
                                <table id="order-listing" class="table">
                                    <thead>
                                        <tr>
                                            <th>ID #</th>
                                            <th>Id Number</th>
                                            <th>Client Name</th>
                                            <th>Debtor Name</th>
                                            <th>Contact No</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $debtors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$debtor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                          <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($debtor->id_number); ?></td>
                                            <td><?php echo e($debtor->debtor_first_name); ?></td>
                                            <td><?php echo e($debtor->first_name); ?></td>
                                            <td><?php echo e($debtor->contact_no); ?></td>
                                            <td><?php echo e($debtor->amount); ?></td>

                                            <td>
                                                <label class="badge badge-info">On hold</label>
                                            </td>
                                            <td>
                                               <a href="<?php echo e(url('debtor/detail',$debtor->id)); ?>"> <button class="btn btn-outline-primary">View</button></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
           <?php echo $__env->make('componant.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('js/data-table.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('componant.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/celothus/file.ceriumsz.online/resources/views/user/index.blade.php ENDPATH**/ ?>